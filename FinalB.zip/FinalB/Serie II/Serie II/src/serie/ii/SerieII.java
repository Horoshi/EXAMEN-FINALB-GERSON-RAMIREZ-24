/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serie.ii;

/**
 *
 * @author estudiante
 */
public class SerieII {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String A = "Su nombre es";
        String B = "Sheyla Davila";
        String C = "Su edad es:";
        int D = 17;
        System.out.print(A + " " + B + " " + C + " " + D + "");
        
        
    }
    
}
