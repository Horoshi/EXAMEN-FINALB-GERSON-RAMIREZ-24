/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serie.iv;

/**
 *
 * @author estudiante
 */
public class SerieIV {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String a = "En";
        int b = 1945;
        String c ="la Segunda Guerra Mundial se estaba desarrollando en Alemania";
        int d = 17250;
        String e = "muertos entre Alemania y la Union Sovietica";
       double f = 0.82;
       int g = 2500;
       String h = "Judios muertos";
        int i = 500;
        String j = "decapitados";
        int k = 100200;
        String l = "soldados";
                
                System.out.println(a + " " + b + " " + c + " " + d + " " + e + " " + f + " " + g + " " + h + " " + i + " " + h + " " + i + " " + j + " " + k + " " + l + "");
                
    }
    
}
